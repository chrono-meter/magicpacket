import re, socket
from optparse import OptionParser


if __name__ == '__main__':
    parser = OptionParser(usage='Usage: %prog [options] MAC-address')
    parser.add_option('-d', '--dest', '--destination',
        metavar='hostname[:port]',
        help='destination address (default=%default)',
        dest='dest', default='255.255.255.255:7')

    options, args = parser.parse_args()
    if not args:
        parser.error('no MAC address given')

    if ':' in options.dest:
        addr = options.dest.split(':', 1)
        addr[1] = int(addr[1])
    else:
        addr = options.dest, 7

    if addr[0] == '255.255.255.255':
        addr_list = []
        for ifaddr in socket.gethostbyname_ex(socket.gethostname())[2]:
            addr_list.append((ifaddr.rsplit('.', 1)[0] + '.255', addr[1]))
    else:
        addr_list = [addr, ]

    for arg in args:
        arg = re.sub('[^0-9A-Fa-f]', '', arg)
        mac = ''.join(chr(int(i+j, 16)) for i, j in zip(arg[::2], arg[1::2]))

        for addr in addr_list:
            sock = socket.socket(
                socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
            sock.sendto('\xff' * 6 + mac * 16, tuple(addr))
            #sock.sendto('\xff' * 6 + mac * 20, tuple(addr))


