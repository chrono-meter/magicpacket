from distutils.core import setup
import py2exe


if __name__ == '__main__':
    setup(
        name='magicpacket',
        version='1.0.0',
        license='MIT',
        author='chrono-meter@gmx.net',
        author_email='chrono-meter@gmx.net',
        description='WOL magic packet sender',
        url='http://www.chrono-meter.info/magicpacket',
        options={
            'py2exe': {
                'compressed': True,
                'optimize': 2,
                'bundle_files': 1,
                },
            },
        zipfile=None,
        py_modules=['magicpacket'],
        console=['magicpacket.py'],
        )


